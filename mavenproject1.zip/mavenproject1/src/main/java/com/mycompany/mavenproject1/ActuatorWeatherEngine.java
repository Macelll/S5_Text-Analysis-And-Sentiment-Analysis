package com.mycompany.mavenproject1;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ActuatorWeatherEngine {
    public static void main(String[] args) {
        new Thread(new EngineActuator()).start();
    }
}

class EngineActuator implements Runnable{
    Random rand = new Random();
    String kirimakuatorweather = "kirimakuatorweather";
    ConnectionFactory cf = new ConnectionFactory();
    @Override
    public void run() {
        receiveMsg();     
    }
    public void receiveMsg(){
        try {    
            Connection con = cf.newConnection(); //2
            Channel ch = con.createChannel(); //3
            ch.exchangeDeclare(kirimakuatorweather, "direct");
            String qName = ch.queueDeclare().getQueue();
            ch.queueBind(qName, kirimakuatorweather, "");
            try {
                ch.basicConsume(qName, true, (x, msg)->{
                    String message = new String(msg.getBody(),"UTF-8");
                    System.out.println("ACTUATOR: received the information of weather   ---> " + message);
                    menaikanthrottling();
                }, x->{});
            } catch (IOException ex) {
                Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TimeoutException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void menaikanthrottling(){
        System.out.println("ACTUATOR INFO: NEED TO INCREASE THE ENGINE TO PREVENT TURBULANCING");
    }
}