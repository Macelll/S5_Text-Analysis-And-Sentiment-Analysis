package com.mycompany.mavenproject1;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ActuatorCabinOxygen {
    public static void main(String[] args) {
        new Thread(new OxygenActuator()).start();
    }
}

class OxygenActuator implements Runnable{
    Random rand = new Random();
    String kirimaktuatorpressure = "kirimaktuatorpressure";
    ConnectionFactory cf = new ConnectionFactory();
    @Override
    public void run() {
        receiveMsg();     
    }
    public void receiveMsg(){
        try {    
            Connection con = cf.newConnection(); //2
            Channel ch = con.createChannel(); //3
            ch.exchangeDeclare(kirimaktuatorpressure, "direct");
            String qName = ch.queueDeclare().getQueue();
            ch.queueBind(qName, kirimaktuatorpressure, "");
            try {
                ch.basicConsume(qName, true, (x, msg)->{
                    String message = new String(msg.getBody(),"UTF-8");
                    System.out.println("Actuator: received the information of cabin pressure on the plane   ---> " + message);
                    deployOxygen();
                }, x->{});
            } catch (IOException ex) {
                Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TimeoutException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void deployOxygen(){
        System.out.println("Actuator-info: NEED TO DEPLOY OXYGEN MASK IMMIDIATELY !!!");
    }
}