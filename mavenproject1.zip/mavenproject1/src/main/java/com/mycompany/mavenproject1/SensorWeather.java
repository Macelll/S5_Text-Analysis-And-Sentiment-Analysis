package com.mycompany.mavenproject1;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;


public class SensorWeather {
      public static void main(String[] args) {
        ScheduledExecutorService callsensor = Executors.newScheduledThreadPool(1);
        callsensor.scheduleAtFixedRate(new WeatherSensor(), 0, 4, TimeUnit.SECONDS);   
    }
}

class WeatherSensor implements Runnable {
    Random rand = new Random();
    String myExchange = "exchangeWeather";
    ConnectionFactory cf = new ConnectionFactory();
    @Override
    public void run() {    
        String weather = createitem();
        kirimWeather(weather);          
    }
    public String createitem(){
        Random rand = new Random();
        String WeatherStatus;
        
        int no = rand.nextInt(3);
        
        switch (no) {
            case 0:
                WeatherStatus = "Clear";
                break;
            default:
                WeatherStatus = "Windy";
                break;
        }
        return WeatherStatus;
    }
    public void kirimWeather(String msg){
    try(Connection con = cf.newConnection()){
            Channel chan = con.createChannel();
            chan.exchangeDeclare(myExchange,"direct");
            System.out.println("WEATHER SENSOR: sending weather info to Flight Control  ---> " + msg);
            chan.basicPublish(myExchange,"" , false, null, msg.getBytes());       
        }   
        catch (IOException | TimeoutException ex) {
        } 
    }
}
