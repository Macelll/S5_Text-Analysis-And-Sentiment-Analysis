package com.mycompany.mavenproject1;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SensorCabin {
    public static void main(String[] args) {
        ScheduledExecutorService callsensor = Executors.newScheduledThreadPool(1);
        callsensor.scheduleAtFixedRate(new CabinSensor(), 0, 4, TimeUnit.SECONDS);  
    }
}

class CabinSensor implements Runnable {
    Random rand = new Random();
    String myExchange = "exchangePressure";
    ConnectionFactory cf = new ConnectionFactory();
    @Override
    public void run() {    
        String pressure = createitem();
        kirimpressure(pressure);
    }
    public String createitem(){
        Random rand = new Random();
        String tekananya;
        int no = rand.nextInt(3);
        switch (no) {
            case 0:
                tekananya = "Good";
                break;
            case 1:
                tekananya = "Bad";
                break;
            default:
                tekananya = "Very Bad";
                break;
        }
        return tekananya;
    }
    public void kirimpressure(String msg){
    try(Connection con = cf.newConnection()){
            Channel chan = con.createChannel();
            chan.exchangeDeclare(myExchange,"direct");
            System.out.println("PRESSURE SENSOR: sending cabin pressure status to Flight Control  ---> " + msg);
            chan.basicPublish(myExchange,"" , false, null, msg.getBytes());
        }   
        catch (IOException | TimeoutException ex) {
        } 
    }
}
