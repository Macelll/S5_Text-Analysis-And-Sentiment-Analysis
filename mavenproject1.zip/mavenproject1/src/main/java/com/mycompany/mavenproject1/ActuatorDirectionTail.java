package com.mycompany.mavenproject1;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ActuatorDirectionTail {
    public static void main(String[] args) {
        new Thread(new TailActuator()).start();
    }
}

class TailActuator implements Runnable{
    Random rand = new Random();
    String kirimaktuatordirection = "kirimaktuatordirection";
    ConnectionFactory cf = new ConnectionFactory();
    @Override
    public void run() {
        receiveMsg();     
    }
    public void receiveMsg(){
        try {    
            Connection con = cf.newConnection();
            Channel ch = con.createChannel();
            ch.exchangeDeclare(kirimaktuatordirection, "direct");
            String qName = ch.queueDeclare().getQueue();
            ch.queueBind(qName, kirimaktuatordirection, "");
            try {
                ch.basicConsume(qName, true, (x, msg)->{
                    String message = new String(msg.getBody(),"UTF-8");
                    System.out.println("ACTUATOR: plane direction exceeding more than 20 degrees up ---> " + message);
                    deployTailFlaps();
                }, x->{});
            } catch (IOException ex) {
                Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        } catch (IOException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TimeoutException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void deployTailFlaps(){
        System.out.println("ACTUATOR INFO: NEED TO DEPLOY WING FLAPS TO MANTAIN DIRECTION");
    }
}