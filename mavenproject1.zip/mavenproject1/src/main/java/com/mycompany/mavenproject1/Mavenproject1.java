package com.mycompany.mavenproject1;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Mavenproject1 {

    public static void main(String[] args) {                
        Logic logic = new Logic();
        new Thread(logic).start();
    }
}

class Logic implements Runnable {
    ConnectionFactory cf = new ConnectionFactory();
    String exchangeAltitude = "exchangeAltitude";
    String exchangePressure = "exchangePressure";
    String exchangeDirection = "exchangeDirection";
    String exchangeWeather = "exchangeWeather";
    
    String kirimaktuatoraltitude = "kirimaktuatoraltitude";
    String kirimaktuatorpressure = "kirimaktuatorpressure";
    String kirimaktuatordirection = "kirimaktuatordirection";
    String kirimakuatorweather = "kirimakuatorweather";
    @Override
    public void run() {
        terimaaltitude();
        terimatekanan();
        terimaharah();
        terimacuaca();
    }
    
    public void terimaaltitude(){
        try {       
            Connection con = cf.newConnection();
            Channel ch = con.createChannel();
            ch.exchangeDeclare(exchangeAltitude, "direct");     
            String qName = ch.queueDeclare().getQueue();
            ch.queueBind(qName, exchangeAltitude, ""); 
            try {
                ch.basicConsume(qName, true, (x, msg)->{
                    String message = new String(msg.getBody(),"UTF-8");
                    System.out.println("FLIGHT CONTROL: received altitude info of the plane ---> " + message + " feet");  
                    LogicAltitude(message);
                }, x->{});
            } catch (IOException ex) {
                Logger.getLogger(AltitudeSensor.class.getName()).log(Level.SEVERE, null, ex);
            }      
        } catch (IOException ex) {
            Logger.getLogger(AltitudeSensor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TimeoutException ex) {
            Logger.getLogger(AltitudeSensor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void terimatekanan(){
        try {       
            Connection con = cf.newConnection();
            Channel ch = con.createChannel();
            ch.exchangeDeclare(exchangePressure, "direct");
            String qName = ch.queueDeclare().getQueue();
            ch.queueBind(qName, exchangePressure, "");
            try {              
                ch.basicConsume(qName, true, (x, msg)->{
                    String message = new String(msg.getBody(),"UTF-8");
                    System.out.println("FLIGHT CONTROL: received cabin pressure info of the plane ---> " + message);
                    LogicPressure(message);
                }, x->{});
            } catch (IOException ex) {
//                Logger.getLogger(exchangePressure.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
//            Logger.getLogger(exchangePressure.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TimeoutException ex) {
//            Logger.getLogger(exchangePressure.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void terimaharah(){
        try {       
            Connection con = cf.newConnection();
            Channel ch = con.createChannel();
            ch.exchangeDeclare(exchangeDirection, "direct");
            String qName = ch.queueDeclare().getQueue(); 
            ch.queueBind(qName, exchangeDirection, ""); 
            try {
                ch.basicConsume(qName, true, (x, msg)->{
                    String message = new String(msg.getBody(),"UTF-8");
                    System.out.println("FLIGHT CONTROL: received direction info of plane degrees    ---> " + message);
                    LogicDirection(message);
                }, x->{});
            } catch (IOException ex) {
//                Logger.getLogger(exchangeDirection.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
//            Logger.getLogger(exchangeDirection.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TimeoutException ex) {
//            Logger.getLogger(exchangeDirection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void terimacuaca(){
        try {       
            Connection con = cf.newConnection();
            Channel ch = con.createChannel();    
            ch.exchangeDeclare(exchangeWeather, "direct");
            String qName = ch.queueDeclare().getQueue(); 
            ch.queueBind(qName, exchangeWeather, "");
            try {
                ch.basicConsume(qName, true, (x, msg)->{
                    String message = new String(msg.getBody(),"UTF-8");
                    System.out.println("FLIGHT CONTROL: received weather info of plane  ---> " + message);
                    LogicWeather(message); 
                }, x->{});
            } catch (IOException ex) {
                Logger.getLogger(WeatherSensor.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
            Logger.getLogger(WeatherSensor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TimeoutException ex) {
            Logger.getLogger(WeatherSensor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    //SEND
    public void kirimjawabanweather(String msg){
    try(Connection con = cf.newConnection()){
            Channel chan = con.createChannel();
            chan.exchangeDeclare(kirimakuatorweather,"direct");
            System.out.println("FLIGHT CONTROL: sending weather information ---> " + msg);
            chan.basicPublish(kirimakuatorweather,"" , false, null, msg.getBytes());
        }   
        catch (IOException | TimeoutException ex) {
        } 
    }
    public void kirimjawabanpressure(String msg){
    try(Connection con = cf.newConnection()){
            Channel chan = con.createChannel();
            chan.exchangeDeclare(kirimaktuatorpressure,"direct"); 
            System.out.println("FLIGHT CONTROL: sending cabin pressure status   ---> " + msg);
            chan.basicPublish(kirimaktuatorpressure,"" , false, null, msg.getBytes());
        }   
        catch (IOException | TimeoutException ex) {
        } 
    }
    public void kirimjawabandirection(String msg){
    try(Connection con = cf.newConnection()){
            Channel chan = con.createChannel();
            chan.exchangeDeclare(kirimaktuatordirection,"direct");
            System.out.println("FLIGHT CONTROL: sending plane direction status  ---> " + msg);
            chan.basicPublish(kirimaktuatordirection,"" , false, null, msg.getBytes());
        }   
        catch (IOException | TimeoutException ex) {
        } 
    }
    public void kirimjawabnaltitude(String msg){
    try(Connection con = cf.newConnection()){
            Channel chan = con.createChannel();
            chan.exchangeDeclare(kirimaktuatoraltitude,"direct");
            System.out.println("FLIGHT CONTROL: Sending angle information for Actuator  ---> " + msg + " °");
            chan.basicPublish(kirimaktuatoraltitude,"" , false, null, msg.getBytes());
        }   
        catch (IOException | TimeoutException ex) {
        } 
    }

    public void LogicAltitude(String tempAlt){
        int alt = Integer.parseInt(tempAlt);
        if (alt > 0)
            if (alt > 31000 && alt < 31999){
                kirimjawabnaltitude("15");
                System.out.println("FLIGHT CONTROL: sending info to maintain altitude!");
            }
            else if (alt > 32000 && alt < 36999){
                kirimjawabnaltitude("25");
                System.out.println("FLIGHT CONTROL: sending info to maintain altitude!");
            }
            else if (alt > 37000){
                kirimjawabnaltitude("35");
                System.out.println("FLIGHT CONTROL: sending info to maintain altitude!");
            }
            else if (alt < 29000 && alt > 28000){
                kirimjawabnaltitude("-15");
                System.out.println("FLIGHT CONTROL: sending info to maintain altitude!");
            }
            else if (alt < 27999 && alt > 27000){
                kirimjawabnaltitude("-25");
                System.out.println("FLIGHT CONTROL: sending info to maintain altitude!");
            }
            else if (alt < 26999){
                kirimjawabnaltitude("-35");
                System.out.println("FLIGHT CONTROL: sending info to maintain altitude!");
            }
            else{      
            }
        }
    public void LogicPressure(String pressureInput){
        switch (pressureInput) {
            case "Very Bad":
                System.out.println("FLIGHT CONTROL: sending info to deploy Oxygen Mask!");
                kirimjawabanpressure(pressureInput);
                break;
            default:
                break;
        }
    }
    public void LogicDirection(String directionInput){
        switch (directionInput) {
            case "Plane 10° up":
                System.out.println("FLIGHT CONTROL: sending info to deploy tail flaps to maintain direction!");
                kirimjawabandirection(directionInput);
                break;
            case "Plane 10° down":
                System.out.println("FLIGHT CONTROL: sending info to deploy tail flaps to maintain direction!");
                kirimjawabandirection(directionInput);
                break;
            default:
                break;
        }
    }
    public void LogicWeather(String weatherInput){
        switch (weatherInput) {
            case "Windy":
                System.out.println("FLIGHT CONTROL: sending info to increase Engine speed!");
                kirimjawabanweather(weatherInput);
                break;
            default:
                break;
        }
    }
}
