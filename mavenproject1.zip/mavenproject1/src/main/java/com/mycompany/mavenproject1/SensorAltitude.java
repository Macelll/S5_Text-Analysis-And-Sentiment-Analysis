package com.mycompany.mavenproject1;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;


public class SensorAltitude {
    public static void main(String[] args) {
        ScheduledExecutorService callsensor = Executors.newScheduledThreadPool(1);
        callsensor.scheduleAtFixedRate(new AltitudeSensor(), 0, 4, TimeUnit.SECONDS);
    }
}

class AltitudeSensor implements Runnable {
    Random rand = new Random();
    String myExchange = "exchangeAltitude";
    ConnectionFactory cf = new ConnectionFactory();
    int CurrentAlt = 35000; 
    @Override
    public void run() {    
        Integer altitude = createitem();
        kirimAltitude(Integer.toString(altitude));
        System.out.println("ALTITUDE SENSOR: sending altitude status to Flight Control    ---> " + altitude + " Feet!");  
    }
    public Integer createitem(){
        Random rand = new Random();              
        int change = rand.nextInt(500); //Random for altitude generator of the plane during flying       
            if (rand.nextBoolean()){            
                change*= -1;        
                CurrentAlt+=change;
            }else{
                change*=1;        
            CurrentAlt+=change;
            }
           return CurrentAlt;
    }
    public void kirimAltitude(String msg){
    try(Connection con = cf.newConnection()){
            Channel chan = con.createChannel();
            chan.exchangeDeclare(myExchange,"direct"); 
            chan.basicPublish(myExchange,"" , false, null, msg.getBytes());
        }   
            catch (IOException | TimeoutException ex) {
        } 
    }
}  
