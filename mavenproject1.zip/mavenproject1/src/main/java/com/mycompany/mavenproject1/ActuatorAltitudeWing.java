package com.mycompany.mavenproject1;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class ActuatorAltitudeWing {
    public static void main(String[] args) {
        new Thread(new WingActuator()).start();
    }
}

class WingActuator implements Runnable{
    Random rand = new Random();
    String kirimaktuatoraltitude = "kirimaktuatoraltitude";
    ConnectionFactory cf = new ConnectionFactory();
    @Override
    public void run() {
        receiveMsg();     
    }
    public void receiveMsg(){
        try {    
            Connection con = cf.newConnection();
            Channel ch = con.createChannel();
            ch.exchangeDeclare(kirimaktuatoraltitude, "direct");
            String qName = ch.queueDeclare().getQueue();
            ch.queueBind(qName, kirimaktuatoraltitude, "");
            try {
                ch.basicConsume(qName, true, (x, msg)->{
                    String message = new String(msg.getBody(),"UTF-8");
                    System.out.println("ACTUATOR: set wings on the plane to   ---> " + message + "°");
                    turunflaps();
                }, x->{});
            } catch (IOException ex) {
                Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TimeoutException ex) {
            Logger.getLogger(Logic.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void turunflaps(){
        System.out.println("ACTUTATOR INFO: NEED TO DEPLOY WINGS IMMIDIATELY !!!");
    }
}
