package com.mycompany.mavenproject1;
import java.io.IOException;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;

public class SensorDirection {
    public static void main(String[] args) {
        ScheduledExecutorService callsensor = Executors.newScheduledThreadPool(1);
        callsensor.scheduleAtFixedRate(new DirectorSensor(), 0, 4, TimeUnit.SECONDS);   
    }
}

class DirectorSensor implements Runnable {
    Random rand = new Random();
    String myExchange = "exchangeDirection";
    ConnectionFactory cf = new ConnectionFactory();
    @Override
    public void run() {    
        String direction = createitem();
        sendDirection(direction);
    } 
    public String createitem(){
        Random rand = new Random();
        String DirectionStatus;
        
        int no = rand.nextInt(5);
        
        switch (no) {
            case 0:
                DirectionStatus = "Normal";
                break;
            case 1:
                DirectionStatus = "Plane 5° up";
                break;
            case 2:
                DirectionStatus = "Plane 10° up";
                break;
            case 3:
                DirectionStatus = "Plane 5° down";
                break;                
            default:
                DirectionStatus = "Plane 10° down";
                break;
        }
        return DirectionStatus;
    } 
    public void sendDirection(String msg){
    try(Connection con = cf.newConnection()){
            Channel chan = con.createChannel();
            chan.exchangeDeclare(myExchange,"direct"); //name, type
            System.out.println("DIRECTION SENSOR: Sending direction info to Flight Control  ---> " + msg);
            chan.basicPublish(myExchange,"" , false, null, msg.getBytes());       
        }   
        catch (IOException | TimeoutException ex) {
        } 
    }
}
